import cherrypy
from mqtt_client import MqttClient
from database import Database
from processor import Processor
from model import KNNModel

class MonitoringAPI:
    exposed = True

    def __init__(self, db):
        self.db = db

    @cherrypy.tools.json_out()
    def GET(self, *uri, **params):
        device_id = params.get("device_id")
        if not device_id:
            raise cherrypy.HTTPError(400, "device_id required")

        row = self.db.get_last(device_id)
        if row is None:
            return {"error": "no data"}

        return row

def main():
    db = Database()
    model = KNNModel("knn_model.pkl")

    mqtt = MqttClient(broker="localhost", port=1883, client_id="monitoring")
    processor = Processor(model, db, mqtt)

    mqtt.subscribe("aquarium/+/sensors/agg", processor.process)
    mqtt.connect_and_start()

    conf = {"/": {"request.dispatch": cherrypy.dispatch.MethodDispatcher()}}
    cherrypy.tree.mount(MonitoringAPI(db), "/monitoring", conf)
    cherrypy.config.update({"server.socket_port": 8082})

    cherrypy.engine.start()
    cherrypy.engine.block()

if __name__ == "__main__":
    main()
